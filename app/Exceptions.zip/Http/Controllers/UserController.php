<?php

namespace App\Http\Controllers;

use App\Http\Requests\User\UserRequest;
use App\Http\Resources\UserCollection;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {

        $data['users'] = UserCollection::collection(User::orderby('id', 'DESC')->paginate(20));
        $data['page_title'] = 'User List';
        return view('user.index')->with($data);
    }

    public function create()
    {
        $data['page_title'] = 'Add New User';
        return view('user.add')->with($data);
    }

    public function store(UserRequest $request)
    {
        DB::beginTransaction();
        try {
            $user = User::create($request->all());
            if ($request->file('pro_pic')) {
                $profilePic = $user->id . '_' . time() . '.' . $request->pro_pic->extension();
                $request->pro_pic->move(public_path('uploads/profile'), $profilePic);
                $user->profile_pic = $profilePic;
                $user->save();
            }
            DB::commit();
            return redirect()->route('user-management.index')->with('success', 'Successfully Added');
        } catch (\Throwable $th) {
            // $th->getMessage();
            DB::rollback();
            //throw $th;
            return redirect()->back()->with('error', 'Operation Failed.');;
        }
    }

    public function show($id)
    {
        $data['userManagement'] = User::findOrFail($id);
        $data['page_title'] = 'User Details';
        return view('user.show')->with($data);
    }

    public function edit($id)
    {
        $data['userManagement'] = User::findOrFail($id);
        $data['page_title'] = 'Edit User';
        return view('user.edit')->with($data);
    }

    public function update(UserRequest $request, $id)
    {
        DB::beginTransaction();
        try {
            $user = User::findOrFail($id);
            $input = $request->all();
            $user->fill($input)->save();
            if ($request->file('pro_pic')) {
                $profilePic = $user->id . '_' . time() . '.' . $request->pro_pic->extension();
                $request->pro_pic->move(public_path('uploads/profile'), $profilePic);
                $user->profile_pic = $profilePic;
                $user->save();
            }
            DB::commit();
            return redirect()->route('user-management.index')->with('success', 'Successfully Updated');
        } catch (\Throwable $th) {
            return $th->getMessage();
            DB::rollback();
            //throw $th;
            return redirect()->back();
        }
    }

    public function destroy(Request $request, $id)
    {
        // return $id;
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->route('user-management.index')->with('success', 'Deleted successfully');
    }
}
