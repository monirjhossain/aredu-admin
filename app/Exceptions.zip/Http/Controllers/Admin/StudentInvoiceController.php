<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Session;
use App\Models\Category;
use App\Http\Controllers\Controller;
use App\Http\Requests\Student\StudentRequest;
use App\Models\Account\FinanceEntry;
use App\Models\Document;
use App\Models\Inquiry\Inquiry;
use App\Models\Invoice;
use App\Models\Post\Post;
use App\Models\Product;
use App\Models\Student\Student;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StudentInvoiceController extends Controller
{

    use UploadAble;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $invoices = Invoice::orderBy('id', 'DESC')->with(['student', 'user']);
        $student = '';
        if ($request->input('student')) {
            $student_id = $request->input('student');
            $student = Student::findOrFail($student_id);
            $invoices->where('student_id', $student_id);
        }
        // if($request->input('type')){
        //     $students->where('office_status', $request->input('type'));
        // }
        // if($request->input('search')){
        //     $students->where('first_name', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('last_name', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('study_level', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('subject', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('preferred_country', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('preferred_subject', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('last_education', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('passport', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('email', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('mobile_no', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('address', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('city', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('country', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('zip', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('father_name', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('father_occoupation', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('father_mobile_no', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('mother_name', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('mother_occoupation', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('mother_mobile_no', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('responsible_person', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('note', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('status', 'like', '%'.$request->input('search').'%')
        //     ->orWhereHas('university', function($q) use ($request){
        //         $q->where('post_title', 'like', '%'.$request->input('search').'%');
        //     })
        //     ->orWhere('ssc_result', 'like', '%'.$request->input('search').'%')
        //     ->orWhere('hsc_result', 'like', '%'.$request->input('search').'%')
        //     ;
        // }
        $data['request'] = $request;
        $data['invoices'] = $invoices->paginate(20);
        $data['title'] = 'Invoices';
        $data['type'] = 'invoice';
        $data['student'] = $student;
        $data['url'] = $student? 'student.invoices' : 'finance_entries.invoices';
        // return $data;
        return view('admin.invoices.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $student = '';
        if ($request->input('student')) {
            $student_id = $request->input('student');
            $student = Student::findOrFail($student_id);
        }
        $data['products'] = Product::select('id', 'name')->get();
        $data['documents'] = Document::select('id', 'name')->get();
        $data['student'] = $student;
        $data['students'] = $student ? null : Student::select('id', 'first_name', 'last_name', 'email', 'address', 'mobile_no', 'passport')->orderby('id', 'DESC')->get();
        $data['title'] = 'Invoice Create';
        $data['type'] = 'invoice';
        $data['url'] = $student? 'student.invoices' : 'finance_entries.invoices';
        // return $data;
        return view('admin.invoices.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request;
        DB::beginTransaction();
        try {
            $invoice = new Invoice();
            $invoiceFillableData = $request->only($invoice->getFillable());
            $invoice->fill($invoiceFillableData)->save();
            $invoice->user_id = Auth::user()->id;

            // $serviceFee = ['product' => $request->product, 'price' => $request->price];
            $filtered = [];
            $services = '';
            $products = $request->product;
            $prices = $request->price;
            $ids = $request->ids;
            $count = 1;
            foreach ($products as $index => $product) {
                if ((float) $prices[$index] != 0) {
                    $filtered['product'][] = $product;
                    $filtered['price'][] = $prices[$index];
                    $filtered['id'][] = $ids[$index];
                    $services .= $count .'. '. $product. ' ';
                    $count++;
                }
            }
            if($request->student_id == '' || $request->student_id == null){
                $filtered['student']['full_name'] = $request->first_name . ' ' . $request->last_name;
                $filtered['student']['first_name'] = $request->first_name;
                $filtered['student']['last_name'] = $request->last_name;
                $filtered['student']['email'] = $request->email;
                $filtered['student']['mobile_no'] = $request->mobile_no;
                $filtered['student']['address'] = $request->address;
            }

            // return $filtered;
            $invoice->products = $filtered;
            $invoice->documents = $request->documents;
            $invoice->invoice_no = date('Ym') . $invoice->id;
            $invoice->save();

            FinanceEntry::create([
                'type' => 'income',
                'amount' => $invoice->paid,
                'transaction_date' => now(),
                'student_id' => $invoice->student_id ?? null,
                'created_by' => Auth::id(),
                'description' => 'Invoice #' . $invoice->invoice_no . ' | ' . $services,
                'reference' => 'INV-' . $invoice->invoice_no,
                'categories' => json_encode($filtered['id']),
            ]);

            DB::commit();
            Session::flash('success', 'Created successfully');
            return redirect()->to(route('student.invoices.index', ['student' => $request->student_id]));
        } catch (\Throwable $th) {
            return $th;
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Invoice $invoice)
    {
        // return $invoice;
        $student = Student::findOrFail($invoice->student_id);
        $data['invoice'] = $invoice;
        $data['student'] = $student;
        $data['title'] = 'Invoices of ' . $student->first_name . ' ' . $student->last_name;
        $data['type'] = 'invoice';
        $data['url'] = 'student.invoices';
        $data['user'] = Auth::user();
        $data['documents'] = Document::all();

        // return $data;
        return view('admin.invoices.invoice')->with($data);
    }

    public function edit(Invoice $invoice)
    {

        $data['invoice'] = $invoice;

        // $data['invoices'] = $invoices->paginate(20);
        // $data['title'] = 'Invoices';
        // $data['type'] = 'invoice';
        // $data['student'] = $student;
        // $data['url'] = 'invoices';



        $data['student'] = $invoice->student_id;
        $data['title'] = 'Invoice Edit';
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['universities'] = Post::select('id', 'post_title')->orderby('id', 'DESC')->where('post_type', 'university')->get();
        return $data;
        return view('admin.invoices.edit')->with($data);
    }

    public function update(StudentRequest $request, Student $student)
    {
        // return $request;
        DB::beginTransaction();
        try {
            // $student = new Student();
            $studentFillableData = $request->only($student->getFillable());
            $student->fill($studentFillableData)->save();
            DB::commit();
            Session::flash('success', 'Update successfully');
            return redirect()->route('students.index');
        } catch (\Throwable $th) {
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return redirect()->back();
        }
    }

    public function destroy(Invoice $invoice)
    {
        if ($invoice) {
            $invoice->delete();
            Session::flash('success', 'Invoice deleted successfully');
            return redirect()->to(route('student.invoices.index', ['student' => $invoice->student_id]));
        }
    }
    public function applicationForm()
    {
        $data['title'] = 'Student Application Form';
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['universities'] = Post::select('id', 'post_title')->orderby('id', 'DESC')->where('post_type', 'university')->get();
        return view('frontend.students.create')->with($data);
    }
    public function applicationFormSubmit(StudentRequest $request)
    {
        // return $request;
        DB::beginTransaction();
        try {
            $student = new Student();
            $studentFillableData = $request->only($student->getFillable());
            $student->fill($studentFillableData)->save();
            DB::commit();
            Session::flash('success', 'Created successfully');
            // return redirect()->route('students.index');
            return redirect()->route('application.show', $student->id . '-' . $student->full_name);
        } catch (\Throwable $th) {
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return redirect()->back();
        }
    }
    public function applicationShow(Request $request, $slug)
    {
        $data['student'] = Student::with('university')->findOrfail($slug);
        $data['title'] = 'Student Application Details';
        $data['type'] = 'student';
        $data['url'] = 'students';
        // return $data;
        return view('frontend.students.show')->with($data);
    }
}
