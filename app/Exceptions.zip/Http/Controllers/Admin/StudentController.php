<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Session;
use App\Models\Category;
use App\Http\Controllers\Controller;
use App\Http\Requests\Student\StudentRequest;
use App\Models\Document;
use App\Models\Inquiry\Inquiry;
use App\Models\Post\Post;
use App\Models\Student\Student;
use App\Models\Study;
use App\Models\Subject;
use App\Models\Tag;
use App\Traits\UploadAble;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{

    use UploadAble;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // return $request;
        $students = Student::orderBy('id', 'DESC');
        if ($request->input('subject')) {
            $students->whereHas('subjects', function ($q) use ($request) {
                $q->where('id', $request->input('subject'));
            });
        }
        if ($request->input('university')) {
            $students->whereHas('universities', function ($q) use ($request) {
                $q->where('id', $request->input('university'));
            });
        }
        if ($request->input('study_level')) {
            $students->where('study_level', $request->input('study_level'));
        }
        if ($request->input('intake')) {
            $students->where('intake', $request->input('intake'));
        }
        if ($request->input('type')) {
            $students->where('office_status', $request->input('type'));
        }
        // Passport Number Search
        if ($request->input('passport_search')) {
            $passport = $request->input('passport_search');
        if (strlen($passport) >= 3) {
        $students->where('passport', 'like', '%' . $passport . '%');
        }
        }
        if ($request->input('search')) {
            $students->where('first_name', 'like', '%' . $request->input('search') . '%')
                ->orWhere('last_name', 'like', '%' . $request->input('search') . '%')
                ->orWhere('study_level', 'like', '%' . $request->input('search') . '%')
                ->orWhere('subject', 'like', '%' . $request->input('search') . '%')
                ->orWhere('preferred_country', 'like', '%' . $request->input('search') . '%')
                ->orWhere('preferred_subject', 'like', '%' . $request->input('search') . '%')
                ->orWhere('last_education', 'like', '%' . $request->input('search') . '%')
                ->orWhere('passport', 'like', '%' . $request->input('search') . '%')
                ->orWhere('email', 'like', '%' . $request->input('search') . '%')
                ->orWhere('mobile_no', 'like', '%' . $request->input('search') . '%')
                ->orWhere('address', 'like', '%' . $request->input('search') . '%')
                ->orWhere('city', 'like', '%' . $request->input('search') . '%')
                ->orWhere('country', 'like', '%' . $request->input('search') . '%')
                ->orWhere('zip', 'like', '%' . $request->input('search') . '%')
                ->orWhere('father_name', 'like', '%' . $request->input('search') . '%')
                ->orWhere('father_occoupation', 'like', '%' . $request->input('search') . '%')
                ->orWhere('father_mobile_no', 'like', '%' . $request->input('search') . '%')
                ->orWhere('mother_name', 'like', '%' . $request->input('search') . '%')
                ->orWhere('mother_occoupation', 'like', '%' . $request->input('search') . '%')
                ->orWhere('mother_mobile_no', 'like', '%' . $request->input('search') . '%')
                ->orWhere('responsible_person', 'like', '%' . $request->input('search') . '%')
                ->orWhere('note', 'like', '%' . $request->input('search') . '%')
                ->orWhere('status', 'like', '%' . $request->input('search') . '%')
                ->orWhereHas('university', function ($q) use ($request) {
                    $q->where('post_title', 'like', '%' . $request->input('search') . '%');
                })
                ->orWhere('ssc_result', 'like', '%' . $request->input('search') . '%')
                ->orWhere('hsc_result', 'like', '%' . $request->input('search') . '%');
        }

        $data['request'] = $request;
        $totalStudent = $students->count();
        $data['students'] = $students->paginate(20);
        $data['title'] = 'Student List - ' . $totalStudent;
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['print'] = $request->input('print');
        $data['study_levels'] = Study::all();
        $data['subjects'] = Subject::all();
        $data['intakes'] = $this->intakeCreate();
        $data['universities'] = Post::select('id', 'post_title')->where('post_type', 'university')->get();
        // return $data;
        if ($request->input('print') && $request->input('print') == 'yes') {
            $data['students'] = $students->get();
            return view('admin.students.print')->with($data);
        }
        return view('admin.students.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $currentYear= now()->year;
        $intake = [];
        for ($i=-2; $i < 3 && $i >-3; $i++) {
            $intake [] = 'March-' . ($currentYear+$i);
            $intake [] = 'September-' . ($currentYear+$i);
        }
        $data['intake'] = $intake;

        $data['subjects'] = Subject::select('id', 'name')->get();
        $data['documents'] = Document::select('id', 'name')->get();
        $data['study_level'] = Study::select('id', 'name')->get();

        $data['title'] = 'student Create';
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['universities'] = Post::select('id', 'post_title')->orderby('id', 'DESC')->where('post_type', 'university')->get();

        // return $data;
        return view('admin.students.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request;
        DB::beginTransaction();
        try {
            $student = new Student();
            $studentFillableData = $request->only($student->getFillable());
            $student->fill($studentFillableData)->save();
            $student->user_id = Auth::user()->id;

            $student->subjects()->attach($request->subjects);
            $student->documents()->attach($request->documents);
            $student->universities()->attach($request->universities);

            DB::commit();
            Session::flash('success', 'Created successfully');
            // return redirect()->route('students.index');
            return redirect()->back();
        } catch (\Throwable $th) {
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return $th;
            // return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        //
    }

    public function edit(Student $student)
    {
        // return
        $currentYear= now()->year;
        $intake = [];
        for ($i=-2; $i < 3 && $i >-3; $i++) {
            $intake [] = 'March-' . ($currentYear+$i);
            $intake [] = 'September-' . ($currentYear+$i);
        }
        $data['intake'] = $intake;

        $data['subjects'] = Subject::select('id', 'name')->get();
        $data['documents'] = Document::select('id', 'name')->get();
        $data['study_level'] = Study::select('id', 'name')->get();

        $data['student'] = $student;
        $data['title'] = 'Student Edit';
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['universities'] = Post::select('id', 'post_title')->orderby('id', 'DESC')->where('post_type', 'university')->get();
        return view('admin.students.edit')->with($data);
    }

    public function update(Request $request, Student $student)
    {
        // return $request;
        DB::beginTransaction();
        try {
            // $student = new Student();
            $studentFillableData = $request->only($student->getFillable());
            $student->fill($studentFillableData)->save();

            $student->subjects()->sync($request->subjects);
            $student->documents()->sync($request->documents);
            $student->universities()->sync($request->universities);
            DB::commit();
            Session::flash('success', 'Update successfully');
            return redirect()->route('students.index');
        } catch (\Throwable $th) {
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return redirect()->back();
        }
    }

    public function destroy(Student $student)
    {
        if ($student) {
            $student->delete();
            Session::flash('success', 'student deleted successfully');
            return redirect()->route('students.index');
        }
    }
    public function applicationForm()
    {
        $data['title'] = 'Student Application Form';
        $data['type'] = 'student';
        $data['url'] = 'students';
        $data['universities'] = Post::select('id', 'post_title')->orderby('id', 'DESC')->where('post_type', 'university')->get();
        return view('frontend.students.create')->with($data);
    }
    public function applicationFormSubmit(StudentRequest $request)
    {
        // return $request;
        DB::beginTransaction();
        try {
            $student = new Student();
            $studentFillableData = $request->only($student->getFillable());
            $student->fill($studentFillableData)->save();
            DB::commit();
            Session::flash('success', 'Created successfully');
            // return redirect()->route('students.index');
            return redirect()->route('application.show', $student->id . '-' . $student->full_name);
        } catch (\Throwable $th) {
            DB::rollback();
            Session::flash('error', 'Something went wrong!');
            return redirect()->back();
        }
    }
    public function applicationShow(Request $request, $slug)
    {
        $data['student'] = Student::with('university')->findOrfail($slug);
        $data['title'] = 'Student Application Details';
        $data['type'] = 'student';
        $data['url'] = 'students';
        // return $data;
        return view('frontend.students.show')->with($data);
    }
    public function intakeCreate()
    {
        $currentYear= now()->year;
        $intake = [];
        for ($i=-2; $i < 3 && $i >-3; $i++) {
            $intake [] = 'March-' . ($currentYear+$i);
            $intake [] = 'September-' . ($currentYear+$i);
        }
        return $intake;
    }
}
