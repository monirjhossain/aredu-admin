<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Account\FinanceEntry;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Product;
use App\Models\Student\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FinanceEntryController extends Controller
{
    public function index(Request $request)
    {
        $perPage = request()->get('perpage', 15);
        $type = request()->get('type', '');
        $order = 'asc';
        if($type == 'expense'){
            $order = 'desc';
        }
        $data['entries'] = FinanceEntry::orderBy('transaction_date', $order)
            ->when($type === 'expense', function ($query) {
                $query->where('type', 'expense');
            })
            ->paginate($perPage);

        if($type != 'expense'){
            $firstRow = $data['entries']->first();
            // Calculate opening balance (before first row)
            $data['openingBalance'] = FinanceEntry::where(function($q) use ($firstRow) {
                    $q->where('transaction_date', '<', $firstRow->transaction_date)
                    ->orWhere(function($q2) use ($firstRow) {
                        $q2->where('transaction_date', $firstRow->transaction_date)
                            ->where('id', '<', $firstRow->id);
                    });
                })
                ->get()
                ->reduce(function($carry, $entry) {
                    return $carry + ($entry->type === 'income' ? $entry->amount : -$entry->amount);
                }, 0);
        }
        $data['title'] = $type != 'expense'? 'Finance List' : 'Expense List';
        $data['type'] = $type;
        $data['url'] = 'finance_entries';
        $data['perPage'] = $perPage;
        return view('admin.account.index')->with($data);
    }

    public function create()
    {
        $data['students'] = Student::orderBy('id', 'desc')->select('id', 'first_name', 'last_name', 'passport')->get();
        $data['expenses'] = Expense::orderBy('id', 'desc')->get();
        $data['products'] = Product::orderBy('id', 'desc')->get();
        $data['title'] = 'Expense Create';
        $data['type'] = 'Expense';
        $data['url'] = 'finance_entries';
        return view('admin.account.create')->with($data);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:income,expense',
            'amount' => 'required|numeric',
            'transaction_date' => 'required|date',
            'student_id' => 'nullable|exists:students,id',
            'description' => 'nullable|string',
            'categories' => 'nullable|array',
            'reference' => 'nullable|string',
        ]);
        $validated['categories'] = collect($validated['categories'] ?? [])->filter()->values()->toJson();
        $validated['created_by'] = Auth::id();
        FinanceEntry::create($validated);
        
        return redirect()->route('finance_entries.index')->with('success', 'Entry created successfully.');
    }

    public function edit(FinanceEntry $financeEntry)
    {
        $data['students'] = Student::orderBy('id', 'desc')->get();
        $data['expenses'] = Expense::orderBy('id', 'desc')->get();
        $data['products'] = Product::orderBy('id', 'desc')->get();
        $data['financeEntry'] = $financeEntry;
        $data['title'] = 'Finance Edit';
        $data['type'] = 'finance';
        $data['url'] = 'finance_entries';
        // return $data;
        return view('admin.account.edit')->with($data);       
    }

    public function update(Request $request, FinanceEntry $financeEntry)
    {
        // return $request;
        $validated = $request->validate([
            'type' => 'required|in:income,expense',
            'amount' => 'required|numeric',
            'transaction_date' => 'required|date',
            'student_id' => 'nullable|exists:students,id',
            'description' => 'nullable|string',
            'reference' => 'nullable|string',
            'categories' => 'nullable|array',
            'categories.*' => 'nullable|string',
        ]);

        $validated['categories'] = collect($validated['categories'] ?? [])
        ->filter()
        ->values()
        ->toJson();

    $financeEntry->update($validated);

        return redirect()->route('finance_entries.index')->with('success', 'Entry updated successfully.');
    }

    public function destroy(FinanceEntry $financeEntry)
    {
        $financeEntry->delete();
        return redirect()->route('finance_entries.index')->with('success', 'Entry deleted successfully.');
    }
}
