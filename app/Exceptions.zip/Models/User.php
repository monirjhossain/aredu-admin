<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $fillable = [
        'name',
        'username',
        'role_id',
        'office_id',
        'mobile_no',
        'email',
        'profile_image',
        'email_verified_at',
        'password',
        'profile_pic',
        'signature',
        'remember_token'
    ];
    protected $hidden = [
        'password',
        'remember_token',
    ];
    protected $appends = ['full_name'];
    public function getFullNameAttribute() {
        return ucfirst($this->name);
    }

    public function setPasswordAttribute($value) {
        $this->attributes['password'] = Hash::make($value);
    }
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function todos() {
        return $this->hasMany(Todo::class, 'user_id', 'id');
    }
}
