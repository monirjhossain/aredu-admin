<?php

namespace App\Models\Student;

use App\Models\Document;
use App\Models\Post\Post;
use App\Models\Study;
use App\Models\Subject;
use App\Models\User;
use App\Traits\ModelSearchAble;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Student extends Model
{
    use HasFactory, ModelSearchAble, SoftDeletes;

    protected $table = 'students';
    protected $fillable = [
        'user_id',
        'study_level',
        'subject',
        'preferred_country',
        'preferred_subject',
        'last_education',
        'first_name',
        'last_name',
        'passport',
        'email',
        'mobile_no',
        'address',
        'city',
        'country',
        'zip',
        'father_name',
        'father_occoupation',
        'father_mobile_no',
        'mother_name',
        'mother_occoupation',
        'mother_mobile_no',
        'responsible_person',
        'office_status',
        'note',
        'status',
        'university_id',
        'ssc_result',
        'hsc_result',
        'intake'
    ];
    protected $appends = ['full_name'];
    public function getFullNameAttribute() {
        return ucfirst($this->first_name) . ' ' . ucfirst($this->last_name);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function university()
    {
        return $this->belongsTo(Post::class, 'university_id');
    }


    public function documents()
    {
        return $this->belongsToMany(Document::class);
    }
    public function universities()
    {
        return $this->belongsToMany(Post::class);
    }
    public function subjects()
    {
        return $this->belongsToMany(Subject::class);
    }
    public function studyLevel()
    {
        return $this->hasOne(Study::class, 'id', 'study_level');
    }
}
