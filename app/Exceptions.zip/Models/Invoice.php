<?php

namespace App\Models;

use App\Models\Student\Student;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'invoice_no',
        'student_id',
        'invoice_date',
        'due_date',
        'products',
        'documents',
        'subtotal',
        'discount',
        'tax',
        'grandtotal',
        'paid',
        'due',
        'user_id',
    ];
    protected $casts = [
        'products' => 'array',
        'documents' => 'array',
    ];

    public function student()
    {
        return $this->belongsTo(student::class, 'student_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
