<?php

namespace App\Models\Account;

use App\Models\Student\Student;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FinanceEntry extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'type',
        'amount',
        'transaction_date',
        'student_id',
        'created_by',
        'description',
        'reference',
        'categories',
    ];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}